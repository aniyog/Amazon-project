package Amazon;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TC01 {
	System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	String url = "https://www.amazon.in/";
	String expected_title = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
	driver.get(url);
  @Test
  public void verifyhone() {
	  String actual_title = driver.getTitle();
		if(actual_title.contentEquals(expected_title))
		{
			System.out.println("Test Case Passed");
		}
		else
		{
			System.out.println("Test Case Failed");
		}
	  
  }
}
