package Amazon;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class priortize {
	
	@BeforeTest
	public void beforetest() {
	System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver_win32\\chromedriver.exe");
	ChromeDriver driver = new ChromeDriver();
	String url ="https://amazon.com/";
	String expected_title ="Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
	driver.get(url);
	}
	
	@Test
	/*public void verifyhomepage()
	{
		String actual_title = driver.getTitle();
		if(expected_title.contentEquals(actual_title))
		{
			System.out.println("Test case passed");
		}
		else
		{
			System.out.println("test case failed");
		}*/
	public void TC01method()
	{
		System.out.println("I m A");
	}
	
	@Test
	
		public void TC02method()
		{
			System.out.println("I m c");
		}
	
    @Test
	public void TC03method()
	{
		System.out.println("I m b");
	}
	


}
