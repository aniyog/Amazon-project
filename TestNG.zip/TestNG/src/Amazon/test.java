package Amazon;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class test {
	
	ChromeDriver driver = new ChromeDriver();

	 @BeforeTest
	 public void driver()
	 {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\Hejex\\Downloads\\chromedriver_win32 (4)\\chromedriver.exe");
	  driver = new ChromeDriver();
	 }
	 String launchPageHeading = "//h2[text()='Guru99 Bank']";
	 final String userName_element = "//input[@name='uid']", password_element = "//input[@name='password']",
	   signIn_element = "//input[@name='btnLogin']";
	 final String userName_value = "mngr28642", password_value = "ydAnate";
	 final String managerID = "//td[contains(text(),'Manger Id')]";
	 final String newCustomer = "//a[@href='addcustomerpage.php']", fundTransfer = "//a[@href='FundTransInput.php']";

	 /**
	  * This test case will initialize the webDriver
	  * 
	  */
	 @Test(groups = { "bonding", "strong_ties" })
	 public void tc01LaunchURL() {
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.get("http://www.demo.guru99.com/V4/");
	 }

}
