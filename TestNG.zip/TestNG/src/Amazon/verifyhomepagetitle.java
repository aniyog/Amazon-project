package Amazon;

public @interface verifyhomepagetitle {

}
