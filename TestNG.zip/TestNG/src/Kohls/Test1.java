package Kohls;

import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class Test1 {
  	
	/*@Test 	
	public void TC01test() 
	{ 	
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\aniyo\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe"); 	
		ChromeDriver driver = new ChromeDriver(); 	
		String url = "https://www.kohls.com"; 	
		String expected_title = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in"; 	
		driver.get(url);  	
		String actual_title = driver.getTitle(); 	
		if(expected_title.contentEquals(actual_title)) 
		{ 		
			System.out.println("Title Has Been Matched"); 
		} 	
		else 	
		{ 		
			System.out.println("Title Has Not Been Matched"); 
		} 	
		driver.close();
	}*/
	@Test
	public void TC01test1() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\aniyo\\Downloads\\chromedriver_win32 (3)\\chromedriver.exe"); 
		ChromeDriver driver = new ChromeDriver(); 	
		String url = "https://www.kohls.com"; 
		driver.get(url);
		WebElement search = driver.findElement(By.id("search"));
		search.sendKeys("clothes");
		WebElement submit = driver.findElement(By.xpath("//*[@id=\"site-search\"]/fieldset/input[1]"));
		submit.click();
		 
		WebElement cancel = driver.findElement(By.xpath("/html/body/div[13]/div[2]/div/div[1]"));
		driver.switchTo().newWindow(cancel);	
		//driver.switchTo().alert().dismiss();

		//driver.findElement(By.xpath("//*[@class='dy-lb-close']")).click();
		driver.switchTo().defaultContent();
		WebElement tee = driver.findElement(By.xpath("//*[@id=\"4147498_prod_price\"]/div[3]/p"));
		tee.click();
	}
	

}
