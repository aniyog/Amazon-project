package hospital;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class hosTest {
	
	
	ChromeDriver driver;
	String expected_title = null;
	@BeforeTest
    public void driver()
	{
	System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\chromedriver.exe");
	driver = new ChromeDriver();
	String url = "file:///C:/Users/aniyo/Downloads/Hospital-Management-Html-master/registration.html";
	driver.get(url);
	}
}